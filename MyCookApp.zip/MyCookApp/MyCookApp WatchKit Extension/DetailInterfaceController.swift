//
//  DitailInterfaceController.swift
//  MyCookApp WatchKit Extension
//
//  Created by Семенова Слепцова ИСИП 20 on 09.04.2022.
//

import WatchKit
import Foundation


class DetailInterfaceController: WKInterfaceController {
    
    
    @IBOutlet weak var iconLabell: WKInterfaceLabel!
    @IBOutlet weak var nameLabel: WKInterfaceLabel!
    @IBOutlet weak var recipeImge: WKInterfaceImage!
    @IBOutlet weak var recipeTitlle: WKInterfaceLabel!
    @IBOutlet weak var authorLabel: WKInterfaceLabel!
    
    override func awake(withContext context: Any?) {
        super.awake(withContext: context)
        
        if let model = context as? Model{
            iconLabell.setText(model.emoji)
            nameLabel.setText(model.name)
            recipeImge.setImageNamed(model.image)
            recipeTitlle.setText(model.recipe)
            authorLabel.setText(model.author)
        }
    }

    override func willActivate() {
        // This method is called when watch view controller is about to be visible to user
        super.willActivate()
    }

    override func didDeactivate() {
        // This method is called when watch view controller is no longer visible
        super.didDeactivate()
    }

}
